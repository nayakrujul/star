# star
Powerful arrays in Python

## Documentation

### Install from PIP

```
$ pip install star-array
```

### Import library

```python
import star
```
