from star.star import Array
